public interface Command {
    void execute();
}
